// // // src/middleware/authMiddleware.js
// // const jwt = require("jsonwebtoken");

// // const authMiddleware = (req, res, next) => {
// //   const token = req.header("Authorization")?.replace("Bearer ", "");

// //   if (!token) {
// //     return res.status(401).json({ message: "No token, authorization denied" });
// //   }

// //   try {
// //     const jwtSecret = process.env.JWT_SECRET;
// //     if (!jwtSecret) {
// //       throw new Error("JWT_SECRET is not defined in environment variables");
// //     }
// //     const decoded = jwt.verify(token, jwtSecret);
// //     req.user = decoded; // Attach the decoded user payload to the request
// //     next();
// //   } catch (err) {
// //     res.status(401).json({ message: "Token is not valid" });
// //   }
// // };

// // // module.exports = { protect: authMiddleware };
// // module.exports = authMiddleware;

// // src/middleware/authMiddleware.js
// const jwt = require("jsonwebtoken");
// const asyncHandler = require("express-async-handler"); // IMPORTANT: Add this if you want async error handling

// // The actual middleware function
// const authMiddleware = asyncHandler(async (req, res, next) => { // Wrap in asyncHandler
//     const token = req.header("Authorization")?.replace("Bearer ", "");

//     if (!token) {
//         res.status(401); // Use res.status(401)
//         throw new Error("No token, authorization denied"); // Throw error to be caught by asyncHandler
//     }

//     try {
//         const jwtSecret = process.env.JWT_SECRET;
//         if (!jwtSecret) {
//             res.status(500); // Or handle this as a server config error
//             throw new Error("JWT_SECRET is not defined in environment variables");
//         }
//         const decoded = jwt.verify(token, jwtSecret);
//         req.user = decoded; // Attach the decoded user payload to the request
//         next();
//     } catch (err) {
//         // If it's a JWT error, set a specific message
//         if (err.name === 'JsonWebTokenError') {
//             res.status(401);
//             throw new Error("Token is not valid");
//         }
//         // Otherwise, re-throw the error for asyncHandler
//         res.status(500); // Fallback status
//         throw err;
//     }
// });

// // Export it as a named export 'protect'
// module.exports = { protect: authMiddleware }; // <-- THIS LINE MUST BE UNCOMMENTED AND ACTIVE!


// src/middleware/authMiddleware.js
const jwt = require("jsonwebtoken");
const asyncHandler = require("express-async-handler"); // IMPORTANT: Keep this line

// The actual middleware function
const authMiddleware = asyncHandler(async (req, res, next) => { // Keep wrapped in asyncHandler
    const token = req.header("Authorization")?.replace("Bearer ", "");

    if (!token) {
        res.status(401);
        throw new Error("No token, authorization denied");
    }

    try {
        const jwtSecret = process.env.JWT_SECRET;
        if (!jwtSecret) {
            res.status(500);
            throw new Error("JWT_SECRET is not defined in environment variables");
        }
        const decoded = jwt.verify(token, jwtSecret);
        console.log("--- Decoded JWT Payload (authMiddleware) ---");
        console.log(decoded);
        console.log("--------------------------------------------");
        // Ensure that the user ID is correctly attached.
        // The `decoded` object typically contains the user ID (e.g., `_id` or `id`)
        // from when the token was signed.
        req.user = decoded; // Attach the decoded user payload to the request.
                            // You will access the user's ID as `req.user._id` in controllers.

        next();
    } catch (err) {
        if (err.name === 'JsonWebTokenError') {
            res.status(401);
            throw new Error("Token is not valid");
        }
        res.status(500);
        throw err;
    }
});

// --- CRUCIAL FIX: Export as a named 'protect' property ---
module.exports = { protect: authMiddleware }; // <--- THIS LINE IS NOW ACTIVE!
// module.exports = authMiddleware;             // <--- THIS LINE IS NOW COMMENTED OUT!