// // // src/routes/authRoutes.js
// // const express = require("express");
// // const bcrypt = require("bcryptjs");
// // const jwt = require("jsonwebtoken");
// // const User = require("../models/User"); // Import the User model
// // const authMiddleware = require("../middleware/authMiddleware"); // Import the middleware

// // const router = express.Router();

// // // @route   POST /api/auth/register
// // // @desc    Register user
// // // @access  Public
// // router.post("/register", async (req, res) => {
// //   const { username, email, password } = req.body;

// //   try {
// //     // Check if user already exists by email
// //     let user = await User.findOne({ email });
// //     if (user) {
// //       return res
// //         .status(400)
// //         .json({ message: "User already exists with this email" });
// //     }

// //     // Check if username already exists
// //     user = await User.findOne({ username });
// //     if (user) {
// //       return res.status(400).json({ message: "Username already taken" });
// //     }

// //     // Create new user
// //     user = new User({
// //       username,
// //       email,
// //       password, // Password will be hashed below
// //     });

// //     // Hash password
// //     const salt = await bcrypt.genSalt(10);
// //     user.password = await bcrypt.hash(password, salt);

// //     await user.save();

// //     // Generate JWT
// //     const jwtSecret = process.env.JWT_SECRET;
// //     if (!jwtSecret) {
// //       throw new Error("JWT_SECRET is not defined");
// //     }
// //     const payload = {
// //       id: user.id, // Mongoose virtual getter for _id
// //       username: user.username,
// //     };
// //     const token = jwt.sign(payload, jwtSecret, { expiresIn: "1h" });

// //     res.status(201).json({
// //       message: "User registered successfully",
// //       token,
// //       user: {
// //         id: user.id,
// //         username: user.username,
// //         email: user.email,
// //       },
// //     });
// //   } catch (err) {
// //     console.error(err.message);
// //     res.status(500).send("Server error");
// //   }
// // });

// // // @route   POST /api/auth/login
// // // @desc    Authenticate user & get token
// // // @access  Public
// // router.post("/login", async (req, res) => {
// //   const { email, password } = req.body;

// //   try {
// //     // Check if user exists
// //     const user = await User.findOne({ email });
// //     if (!user) {
// //       return res.status(400).json({ message: "Invalid Credentials" });
// //     }

// //     // Check password
// //     const isMatch = await bcrypt.compare(password, user.password);
// //     if (!isMatch) {
// //       return res.status(400).json({ message: "Invalid Credentials" });
// //     }

// //     // Generate JWT
// //     const jwtSecret = process.env.JWT_SECRET;
// //     if (!jwtSecret) {
// //       throw new Error("JWT_SECRET is not defined");
// //     }
// //     const payload = {
// //       id: user.id,
// //       username: user.username,
// //     };
// //     const token = jwt.sign(payload, jwtSecret, { expiresIn: "1h" });

// //     res.status(200).json({
// //       message: "Logged in successfully",
// //       token,
// //       user: {
// //         id: user.id,
// //         username: user.username,
// //         email: user.email,
// //       },
// //     });
// //   } catch (err) {
// //     console.error(err.message);
// //     res.status(500).send("Server error");
// //   }
// // });

// // // @route   GET /api/auth/me
// // // @desc    Get current user data
// // // @access  Private (requires token)
// // router.get("/me", authMiddleware, async (req, res) => {
// //   try {
// //     // req.user is set by the authMiddleware
// //     if (!req.user || !req.user.id) {
// //       return res.status(401).json({ message: "User not authenticated" });
// //     }
// //     const user = await User.findById(req.user.id).select("-password"); // Exclude password
// //     if (!user) {
// //       return res.status(404).json({ message: "User not found" });
// //     }
// //     res.json(user);
// //   } catch (err) {
// //     console.error(err.message);
// //     res.status(500).send("Server error");
// //   }
// // });

// // module.exports = router;

// // src/middleware/authMiddleware.js
// const jwt = require("jsonwebtoken");
// const asyncHandler = require("express-async-handler"); // IMPORTANT: Add this if you want async error handling

// // The actual middleware function
// const authMiddleware = asyncHandler(async (req, res, next) => { // Wrap in asyncHandler
//   const token = req.header("Authorization")?.replace("Bearer ", "");

//   if (!token) {
//     res.status(401); // Use res.status(401)
//     throw new Error("No token, authorization denied"); // Throw error to be caught by asyncHandler
//   }

//   try {
//     const jwtSecret = process.env.JWT_SECRET;
//     if (!jwtSecret) {
//       res.status(500); // Or handle this as a server config error
//       throw new Error("JWT_SECRET is not defined in environment variables");
//     }
//     const decoded = jwt.verify(token, jwtSecret);
//     req.user = decoded; // Attach the decoded user payload to the request
//     next();
//   } catch (err) {
//     // If it's a JWT error, set a specific message
//     if (err.name === 'JsonWebTokenError') {
//         res.status(401);
//         throw new Error("Token is not valid");
//     }
//     // Otherwise, re-throw the error for asyncHandler
//     res.status(500); // Fallback status
//     throw err;
//   }
// });

// // Export it as a named export 'protect'
// // module.exports = { protect: authMiddleware };
// const { protect } = require("../middleware/authMiddleware");

// src/routes/authRoutes.js
const express = require("express");
const { registerUser, loginUser, getMe } = require("../controllers/authController"); // Import controller functions
const { protect } = require("../middleware/authMiddleware"); // Import the 'protect' middleware

const router = express.Router();

// @route   POST /api/auth/register
// @desc    Register user
// @access  Public
router.post("/register", registerUser);

// @route   POST /api/auth/login
// @desc    Authenticate user & get token
// @access  Public
router.post("/login", loginUser);

// @route   GET /api/auth/me
// @desc    Get current user data
// @access  Private (requires token)
router.get("/me", protect, getMe); // Use the 'protect' middleware to secure this route

module.exports = router;